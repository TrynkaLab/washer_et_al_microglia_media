###### Multiple linear regression model for qPCR Data ##########
results=read.csv("Micro001_All_Markers.csv",header=TRUE,row.names=1,stringsAsFactors = FALSE)
results=results[order(results$Media),]

##### reformat the data into two tables: one with Rownames as Genes and columns as the ddCT values and another as a pheno file with rownames as samples and colnames as grouping variables

ddCT=matrix(data=results$ddCT,nrow=length(unique(results$Gene)),ncol=length(unique(results$Media)),byrow = FALSE)
colnames(ddCT)=unique(results$Media)
rownames(ddCT)=unique(results$Gene)

pheno=unique(results[,c(1:8)])
rownames(pheno)=pheno[,1]

##### prepare a results matrix

results_matrix=matrix(data=NA, nrow= (14*8),ncol=4)
colnames(results_matrix)=c("Gene/Factor","Beta","SE","Pval")

name_vector=c()
for(i in unique(results$Gene)){
  name=paste(i,unique(colnames(pheno)),sep="_")
  name_vector=c(name_vector,name)
  }

results_matrix[,1]=name_vector

##### run the linear regression model 

model_coefficients=c()
model_SE=c()
model_pval=c()

for(i in 1:nrow(ddCT)){
  model=lm(ddCT[i,]~ pheno$BME + pheno$N2 + pheno$GMCSF + pheno$IL34 + pheno$MCSF + pheno$TGFB + pheno$CD200)
  ###average CT Change
  model_coefficients=c(model_coefficients,summary(model)$coefficients[,1])
  ###error
  model_SE=c(model_SE,summary(model)$coefficients[,2])
  ###pvals
  model_pval=c(model_pval,summary(model)$coefficients[,4])
}

results_matrix[,2]=model_coefficients
results_matrix[,3]=model_SE
results_matrix[,4]=model_pval

### Replace the Gene_Media name with Gene_Intercept as media not used as a covariate in the model. 

results_matrix=as.data.frame(results_matrix)
results_matrix$`Gene/Factor`=gsub("_Media","_Intercept",results_matrix$`Gene/Factor`)

library(stringr)
library(dplyr)

splitting=str_split_fixed(results_matrix$`Gene/Factor`,"_",2)
results_matrix$Gene=splitting[,1]
results_matrix$Covariate=splitting[,2]

## Reorder the final DF

results_matrix = results_matrix %>% select("Gene/Factor","Gene","Covariate","Beta","SE","Pval")
results_matrix=as.matrix(results_matrix)

## perform bonferroni correction on p values

p.adjust(results_matrix[1,6],method="bonferroni",n=nrow(results_matrix))

## plot data
library(ggplot2)

results_df=as.data.frame(results_matrix)
results_df$Pval=as.numeric(as.character(results_df$Pval))
results_df$Pval=format(round(results_df$Pval,3),nsmall=3)
results_df$FoldStar=format(round(results_df$Fold,3),nsmall=3)
results_df$Pval=as.numeric(results_df$Pval)
results_df=results_df[!results_df$Covariate=="Intercept",]
results_df$Gene

write.csv(results_df,"Micro001_lm_full_model_results.csv")
## add significance stars manually in excel

results_df=read.csv("Micro001_lm_full_model_results_starred.csv",header=TRUE)
### Caluculate the fold changes

results_df$Beta=as.numeric(as.character(results_df$Beta))
results_df$Fold=2^-results_df$Beta

results_df$Covariate=gsub("GMCSF","GM-CSF",results_df$Covariate)
results_df$Covariate=gsub("MCSF","M-CSF",results_df$Covariate)
results_df$Covariate=gsub("IL34","IL-34",results_df$Covariate)
results_df$Covariate=gsub("TGFB","TGFb1",results_df$Covariate)
results_df$Gene=gsub("CD200","CD200R1",results_df$Gene)

results_df$Covariate=as.factor(results_df$Covariate)
results_df$Covariate=factor(results_df$Covariate,c("IL-34","TGFb1","M-CSF","GM-CSF","CD200/CX3CL1","BME","N2"))
levels(results_df$Covariate)

ggplot(data=results_df,aes(x=Covariate,y=Gene,fill=Beta))+
  geom_tile()+
  scale_fill_gradient2(low="green",mid="white",high="red",name="Beta")+
  geom_text(aes(x=Covariate,y=Gene,label=FoldStar),color="black",size=3)+
  theme(panel.grid.major=element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        legend.position = "none",
        plot.title=element_text(hjust=0.5,size=14,face="bold"),
        axis.title=element_text(size=12,face="bold"),
        axis.text.y = element_text(face="italic"),
        axis.text.x = element_text(angle=45,vjust=0.68),
        axis.ticks.y= element_blank())+
  labs(x="Factor",title="")

ggsave(plot=last_plot(), filename="Micro001_All_Markers_Linear_Regression_Pvalues_betas.jpeg",device="jpeg",width=6,height=6)


plot_betas=ggplot(results_df,aes(x=Gene.Factor,y=Beta,fill=Gene))+
  geom_bar(data=results_df, stat="identity",position=position_dodge(),alpha=.5)+
  geom_errorbar(data=results_df, aes(ymin=Beta-SE, ymax=Beta+SE),width=.1,position=position_dodge(.9),color="Black")+
  labs(title="Linear Regression ddCT Values",y="ddCT",x="Gene_Factor")+
  theme_classic()+
  theme(plot.title = element_text(family="Arial",face="bold",size=10,hjust=0.5))+
  theme(axis.text = element_text(family="Arial",size=10))+
  theme(axis.text.x=element_text(angle = 45,hjust = 1,family="Arial",size=6))+
  theme(axis.title = element_text(family="Arial",size=10,face="bold"))+
  theme(legend.text= element_text(family="Arial",size=8))+
  theme(legend.title = element_text(family="Arial",size=10,face="bold"))+
  theme(legend.key.size = unit(0.4,"cm"))
print(plot_betas)

ggsave(plot=last_plot(), filename="Micro001_All_Markers_Linear_Regression_barplot_DDCT.jpeg",device="jpeg",width=12,height=6)

sessionInfo()
# R version 4.2.0 (2022-04-22 ucrt)
# Platform: x86_64-w64-mingw32/x64 (64-bit)
# Running under: Windows 10 x64 (build 18363)
# 
# Matrix products: default
# 
# locale:
#   [1] LC_COLLATE=English_United Kingdom.utf8  LC_CTYPE=English_United Kingdom.utf8  
# [3] LC_MONETARY=English_United Kingdom.utf8 LC_NUMERIC=C                          
# [5] LC_TIME=English_United Kingdom.utf8   
# 
# attached base packages:
#   [1] stats     graphics  grDevices utils     datasets  methods   base    
# 
# other attached packages:
#   [1] ggplot2_3.3.6 dplyr_1.0.9   stringr_1.4.0
# 
# loaded via a namespace (and not attached):
#   [1] magrittr_2.0.3   tidyselect_1.1.2 munsell_0.5.0    colorspace_2.0-3 R6_2.5.1         rlang_1.0.2    
# [7] fansi_1.0.3      tools_4.2.0      grid_4.2.0       gtable_0.3.0     utf8_1.2.2       cli_3.3.0      
# [13] DBI_1.1.2        withr_2.5.0      ellipsis_0.3.2   digest_0.6.29    assertthat_0.2.1 tibble_3.1.7   
# [19] lifecycle_1.0.1  crayon_1.5.1     farver_2.1.0     purrr_0.3.4      vctrs_0.4.1      glue_1.6.2     
# [25] labeling_0.4.2   stringi_1.7.6    compiler_4.2.0   pillar_1.7.0     generics_0.1.2   scales_1.2.0   
# [31] pkgconfig_2.0.3