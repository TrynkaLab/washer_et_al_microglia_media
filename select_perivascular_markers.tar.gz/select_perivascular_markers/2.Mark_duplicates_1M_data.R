## Marking duplicates
# where to look for libraries when running on server:
.libPaths("/lustre/scratch117/cellgen/teamtrynka/marta/bin/R/R-4.0.0/lib")


library(TENxBrainData)
library(Seurat)
library(SingleCellExperiment)
library(glmGamPoi) # To speed up SCTransform
library(future)
library(patchwork)
library(ggplot2)
library(DoubletFinder)
options(DelayedArray.block.size=2e9) # Give 2GB memory to single cell experiment
options(future.globals.maxSize= 2097152000) # 2Gb for seurat
plan("multiprocess", workers = 4) # more workers
# check the current active plan
plan()
# Helper function to calculate running time
hms_span <- function(start, end) {
  dsec <- as.numeric(difftime(end, start, unit = "secs"))
  hours <- floor(dsec / 3600)
  minutes <- floor((dsec - 3600 * hours) / 60)
  seconds <- dsec - 3600*hours - 60*minutes
  paste0(
    sapply(c(hours, minutes, seconds), function(x) {
      formatC(x, width = 2, format = "d", flag = "0")
    }), collapse = ":")
}

####  data


# load full data
tenx <- TENxBrainData()
tenx # SingleCellExperiment class

## Marking duplicates per library
mark_duplicates_1M_cells = function(sce) {
  timeStartWhole = Sys.time() 
  duplicates_cell_barcodes = list()
  for(library in unique(colData(tenx)$Library)) {
    timeStart = Sys.time() 
      sce_subset = sce[, colData(sce)$Library == library]
      message("Working on library ",library,"...")
  
    rownames(sce_subset) = as.character(rowData(sce_subset)[, 2])
    seurat = as.Seurat(sce_subset, data = NULL)
    # Manually adding metadata
    seurat@meta.data$nFeature_RNA = colSums(seurat@assays$RNA@counts > 0) #number of genes: all genes that have expression over 0 count
    seurat@meta.data$nCount_RNA = colSums(seurat@assays$RNA@counts)
    seurat[["percent.mt"]] =  PercentageFeatureSet(seurat, pattern = "^mt-")
    
    #Filter
    seurat = subset(seurat, subset = nFeature_RNA > 300 & percent.mt < 10)
    message("There are  ", nrow(seurat@meta.data), " cells now")
    
    # Normalise
    seurat = SCTransform(seurat, method = "glmGamPoi", verbose = T)
    
    
    calculate_PCA_UMAP_neighbors_clusters = function(seurat_object){
      timeStart <- Sys.time()
      
      seurat_object <- RunPCA(seurat_object, verbose = FALSE)
      
      seurat_object <- FindNeighbors(seurat_object, dims = 1:30, verbose = FALSE)
      seurat_object <- FindClusters(seurat_object,
                                    verbose = FALSE)
      
      seurat_object <- RunUMAP(seurat_object, dims = 1:30, verbose = FALSE)
      
      timeEnd <- Sys.time() 
      message("Time elapsed calculating PCA, clusters and UMAP = ", hms_span(timeStart, timeEnd))
      
      return(seurat_object)
    }
    
    seurat = calculate_PCA_UMAP_neighbors_clusters(seurat)
    
    # Doublet finder
    # PK identification: no ground truth
    
    pk_identification = function(sct_seurat_object) {
      sweep.res.list <- paramSweep_v3(sct_seurat_object, PCs = 1:10, sct = TRUE)
      sweep.stats <- summarizeSweep(sweep.res.list, GT = FALSE)
      bcmvn <- find.pK(sweep.stats)
      return (bcmvn)
    }
    
    bcmvn = pk_identification(seurat)

    bcmvn$pK = as.numeric(as.character(bcmvn$pK))

    png(paste0("../inspection_1M/doublets/pk_BCmetric_library_",library,".png"),
        width = 6, height = 4, units = "in", res = 400)
    p=ggplot(bcmvn,aes(x=pK,y=BCmetric, group = 1)) + geom_line() + geom_point() +theme_bw()
    print(p)
    dev.off()
    
    # In general, it's better to select the lower pK that maximizes the BCmetric
    pk = bcmvn[which(bcmvn$BCmetric == max(bcmvn$BCmetric)),"pK"]
    ## Homotypic Doublet Proportion Estimate -------------------------------------------------------------------------------------
    model_expected_doublets = function(seurat_object, expected_doublet_rate){
      annotations =  as.character(seurat_object$seurat_clusters)
      homotypic.prop <- modelHomotypic(annotations)   
      nExp_poi = round(expected_doublet_rate * nrow(seurat_object@meta.data))
      nExp_poi.adj <- round(nExp_poi*(1-homotypic.prop))
      
      return(list(nExp_poi,nExp_poi.adj))
    }
    # The expected doublet rate depends on the number of cells loaded and the technology used for sequencing. 
    
    poi = model_expected_doublets(seurat, expected_doublet_rate = 0.076) 
    
    DF_classification = function(seurat_object, pk, poi_list){
      
      
      # All confidence doublets
      seurat_object.doublet <-
        doubletFinder_v3(
          seurat_object,
          PCs = 1:10,
          pN = 0.25,
          pK = pk,
          nExp = poi_list[[1]], # not adjusted for homotypic doublets
          reuse.pANN = FALSE,
          sct = TRUE
        )
      # High confidence doublets
      
      seurat_object.doublet <-
        doubletFinder_v3(
          seurat_object.doublet,
          PCs = 1:10,
          pN = 0.25,
          pK = pk,
          nExp = poi_list[[2]], 
          reuse.pANN = colnames(seurat_object.doublet@meta.data)[ncol(seurat_object.doublet@meta.data)-1],
          sct = TRUE
        )
      # Integrate info all and high confidence
      seurat_object.doublet@meta.data$DF_confidence = "Singlet"
      seurat_object.doublet@meta.data[seurat_object.doublet[[colnames(seurat_object.doublet@meta.data)[ncol(seurat_object.doublet@meta.data) -
                                                                                                         2]]] == "Doublet" &
                                        seurat_object.doublet[[colnames(seurat_object.doublet@meta.data)[ncol(seurat_object.doublet@meta.data)-1]]] == "Doublet",
                                      "DF_confidence"] = "High_confidence_doublet"
      
      seurat_object.doublet@meta.data[seurat_object.doublet[[colnames(seurat_object.doublet@meta.data)[ncol(seurat_object.doublet@meta.data) -
                                                                                                         2]]] == "Doublet" &
                                        seurat_object.doublet[[colnames(seurat_object.doublet@meta.data)[ncol(seurat_object.doublet@meta.data)-1]]] == "Singlet",
                                      "DF_confidence"] = "Low_confidence_doublet"
      
      return(seurat_object.doublet)
    }
    
    seurat.doublet = DF_classification(seurat, pk = pk, poi_list = poi)
    
    UMAPS_per_lib = function(seurat_object) {
      timeStart <- Sys.time()
      
      p2 =FeaturePlot(seurat_object, label = F, features  = "percent.mt", order = TRUE) + 
        ggtitle("Mit percent") 
      p3 = FeaturePlot(seurat_object, label = F, features  = "nFeature_RNA", order = TRUE) + 
        ggtitle("Number of genes")
      

      p5 = DimPlot(seurat_object, label = F, group.by = "DF_confidence", 
                   cols = c('Singlet' = '#28C2FF', 'High_confidence_doublet' = '#BD6B73', 
                                                                                  'Low_confidence_doublet' = '#FFA630')) + 
        ggtitle("DoubletFinder doublets") 
      p6 = DimPlot(seurat_object, label = F,group.by = "Mouse") + ggtitle("Mouse")
      
      p = (p2 | p3) / (p5 | p6) 
      
      timeEnd <- Sys.time() 
      message("Time elapsed plotting UMAPS = ", hms_span(timeStart, timeEnd))
      
      return(p)
    }
    
    p = UMAPS_per_lib(seurat.doublet)
    
    png( paste0("../inspection_1M/doublets/UMAP_duplicates_library_", library, ".png"), 
         width = 10, height = 12, units = "in", res = 400)
    print(p)
    dev.off()
    
    duplicates_cell_barcodes[[library]] = seurat.doublet@meta.data[seurat.doublet@meta.data$DF_confidence == "High_confidence_doublet","Barcode"]
    
    timeEnd <- Sys.time() 
    message("Time elapsed per chunk = ", hms_span(timeStart, timeEnd))
    gc()
    
  }
  return(duplicates_cell_barcodes)
  timeEndWhole <- Sys.time() 
  message("Time elapsed for all chunks = ", hms_span(timeStartWhole, timeEndWhole))
  
}

duplicates_cell_barcodes = mark_duplicates_1M_cells(tenx)
barcode_vector = unlist(duplicates_cell_barcodes)

write.table(barcode_vector,"../duplicates_cell_barcodes.txt",row.names = F, quote = F, col.names = F)

