## Inspect enriched microglia object


library(Seurat)
library(SingleCellExperiment)
library(glmGamPoi) # To speed up SCTransform, only available in R4
library(future)
library(patchwork)
library(ggplot2)
library(biomaRt)
library(tidyverse)

options(future.globals.maxSize= 2097152000) # 2Gb for seurat
plan("multiprocess", workers = 18) # more workers
# check the current active plan
plan()

# Load un-filtered data

seurat = readRDS("../seurat_30K_microglia_enriched_nofilters.rds")

# load list of genes to use as microglia classifier
microglia_enriched_genes = read.table("../genes_for_microglial_scoring.txt")
microglia_enriched_genes = microglia_enriched_genes$gene

# Manually adding metadata
seurat@meta.data$nFeature_RNA = colSums(as.matrix(seurat@assays$RNA@counts > 0)) #number of genes: all genes that have expression over 0 count
seurat@meta.data$nCount_RNA = colSums(as.matrix(seurat@assays$RNA@counts))
seurat[["percent.mt"]] =  PercentageFeatureSet(seurat, pattern = "^mt-")


## Mouse genes to human orthologs
# get human gene names with biomart
mouse_to_human = function(x){
  
  human = useMart("ensembl", dataset = "hsapiens_gene_ensembl")
  mouse = useMart("ensembl", dataset = "mmusculus_gene_ensembl")
  
  genesV2 = getLDS(attributes = c("mgi_symbol"), filters = "mgi_symbol", 
                   values = x , mart = mouse, attributesL = c("hgnc_symbol","ensembl_gene_id"), martL = human, 
                   uniqueRows=T)
  message("There are ", anyDuplicated(genesV2[, 2]), " duplicated human gene names")
  message("There are ", anyDuplicated(genesV2[, 3]), " duplicated human gene ids")
  
  ## Removing mouse genes that are not found in human and duplicates
  humanx <- genesV2[genesV2$HGNC.symbol != "",] 
  humanx <- humanx[which(!duplicated(humanx$HGNC.symbol)),] 
  humanx <- humanx[which(!duplicated(humanx$MGI.symbol)),] 
  
  message("After removing duplicates, there are ", anyDuplicated(humanx[, 1]), " duplicated mouse gene names")
  message("After removing duplicates, there are ", anyDuplicated(humanx[, 2]), " duplicated human gene names")
  message("After removing duplicates, there are ", anyDuplicated(humanx[, 3]), " duplicated human gene ids")
  
  print(head(humanx))
  return(humanx)
}
assayobj = GetAssayData(object = seurat,
                        assay = "RNA", slot = "data")
mouse_genes = row.names(assayobj)
human_mouse_genes = mouse_to_human(mouse_genes)
microglia_enriched_genes_human = mouse_to_human(microglia_enriched_genes)$HGNC.symbol
## Removing some mouse genes that are not in the data: don't know how they got here
human_mouse_genes = human_mouse_genes[human_mouse_genes$MGI.symbol!="Frmpd2",]
## Subsetting to mouse genes that have human orthologues, rename genes to human orthologs,
# and pull old metadata
subset_by_common_genes_and_rename = function(seurat_object, common_genes) {
  subset.matrix = GetAssayData(object = seurat_object,
                               assay = "RNA", slot = "counts")
  subset.matrix = subset.matrix[common_genes$MGI.symbol,]
  rownames(subset.matrix) = common_genes[match(common_genes$MGI.symbol,
                                               rownames(subset.matrix)),"HGNC.symbol"]
  subset_seurat_object =  CreateSeuratObject(subset.matrix) # Create a new Seurat object with just the genes of interest
  subset_seurat_object = AddMetaData(object = subset_seurat_object, metadata = seurat_object@meta.data) # Add the idents to the meta.data slot
  return(subset_seurat_object)
}

human_seurat = subset_by_common_genes_and_rename(seurat_object=seurat, common_genes = human_mouse_genes)

## scoring cell cycle genes 

human_seurat = CellCycleScoring(
  human_seurat,
  s.features = cc.genes.updated.2019$s.genes,
  g2m.features = cc.genes.updated.2019$g2m.genes,
  set.ident = F
)



#Filter
human_seurat = subset(human_seurat, subset = nFeature_RNA > 300 & percent.mt < 10)
message("There are  ", nrow(human_seurat@meta.data), " cells now")

########################## regress out mouse and cell cycle effect ################################


human_seurat = SCTransform(human_seurat,
                           method = "glmGamPoi", verbose = T)


## Scoring cell types -  mostly based on Tasic et al., 2016
# major known marker genes: Snap25 (pan-neuronal); 
# Gad1 (pan-GABAergic); Vip, Sst and Pvalb (GABAergic); 
# Slc17a7 (pan-glutamatergic); Rorb (mostly L4 and L5a); Foxp2 (L6); 
# Aqp4 (astrocytes); Pdgfra (oligodendrocyte precursor cells, OPCs); 
# Mog (oligodendrocytes); Itgam (microglia); Flt1 (endothelial cells) 
# and Bgn (smooth muscle cells, SMC).
# Also Allen mouse brain cell atlas
cell_type_list = list(microglia = c(microglia_enriched_genes_human,"ITGAM"),
                      neurons = c("SNAP25"),
                      GABAergic_neurons = c("SNAP25", "GAD1", "VIP","SST","SLC32A1"), 
                      GABAergic_neurons_SST = c("SNAP25","GAD1", "SST"), #Sst, subset of GABAergic neurons
                      glutamanergic_neurons_RORB=c("SLC17A7","SNAP25","RORB"), #Rorb, subset of glutamanergic neurons
                      glutamanergic_neurons_FOXP2=c("SLC17A7","SNAP25","FOXP2"), #Foxp2, subset of glutamanergic neurons
                      astrocytes=c("AQP4","GFAP","SOX9","CXCL14"), 
                      oligodendrocyte_precursor_cells=c("PDGFRA","OLIG1","CSPG4","TOP2A"), 
                      oligodendrocytes = c("PDGFRA"), 
                      endothelial_cells = c("FLT1","ID1"), 
                      smooth_muscle_cells = c("BGN","VTN","CRIP1","MYL9")) 
                      
  
score_cell_types = function(seurat_object, named_list_of_features) {
  for (n in names(named_list_of_features)) {
    message(paste0("Working on module ", n))
    seurat_object <- AddModuleScore(
      object = seurat_object,
      features = list(named_list_of_features[[n]]),
      ctrl = 100,
      name = paste0(n,'_feature_score')
    )
  }
  return(seurat_object)
}

human_seurat = score_cell_types(human_seurat,named_list_of_features = cell_type_list)

calculate_PCA_UMAP_neighbors_clusters = function(seurat_object,res){
  
  seurat_object <- RunPCA(seurat_object, verbose = FALSE)
  
  seurat_object <- FindNeighbors(seurat_object, dims = 1:30, verbose = FALSE)
  seurat_object <- FindClusters(seurat_object,
                                verbose = FALSE,resolution = res) 
  
  seurat_object <- RunUMAP(seurat_object, dims = 1:30, verbose = FALSE)
  
  return(seurat_object)
}

human_seurat = calculate_PCA_UMAP_neighbors_clusters(human_seurat, res = 0.3) # Lower resolution to get less clusters, checked with clustree


UMAPS = function(seurat_object) {
  
  p1 = DimPlot(seurat_object, label = TRUE) + NoLegend() + ggtitle("Clusters")
  p2 =FeaturePlot(seurat_object, label = F, features  = "percent.mt", order = TRUE) + 
    ggtitle("Mit percent") 
  p3 = FeaturePlot(seurat_object, label = F, features  = "nFeature_RNA", order = TRUE) + 
    ggtitle("Number of genes")
  p4 = FeaturePlot(seurat_object, label = F, features  = "microglia_feature_score1", order = TRUE) + 
    ggtitle("Microglia score")
  p5 = DimPlot(seurat_object, label = F,group.by = "Library") + NoLegend() + ggtitle("Library")
  p6 = DimPlot(seurat_object, label = F,group.by = "Mouse") + ggtitle("Mouse")
  p7 = DimPlot(seurat_object, label = F, group.by = "Phase") + ggtitle("Cell cycle phase")
  
  p = (p1 | p2) / (p3 | p4) / (p5 | p6) / (p7 | patchwork::plot_spacer())
  
  return(p)
}


p = UMAPS(human_seurat)

png( paste0("../inspection_30k_microglia_enriched/UMAP_30k_cells_noRegression.png"), 
     width = 8, height = 14, units = "in", res = 400)
print(p)
dev.off()

UMAP_scores = function(seurat_object) {
  
  p2 =FeaturePlot(seurat_object, label = F, features  = "microglia_feature_score1", order = TRUE) + 
    ggtitle("Microglia score")
  p3 = FeaturePlot(seurat_object, label = F, features  = "GABAergic_neurons_feature_score1", order = TRUE) + 
    ggtitle("GABAergic neurons score")
  p4 = FeaturePlot(seurat_object, label = F, features  = "GABAergic_neurons_SST_feature_score1", order = TRUE) + 
    ggtitle("GABAergic neurons SST score")
  p5 = FeaturePlot(seurat_object, label = F, features  = "glutamanergic_neurons_RORB_feature_score1", order = TRUE) + 
    ggtitle("glutamanergic_neurons_RORB score")
  p6 = FeaturePlot(seurat_object, label = F, features  = "glutamanergic_neurons_FOXP2_feature_score1", order = TRUE) + 
    ggtitle("glutamanergic_neurons_FOXP2 score")
  p7 = FeaturePlot(seurat_object, label = F, features  = "astrocytes_feature_score1", order = TRUE) + 
    ggtitle("astrocytes score")  
  p8 = FeaturePlot(seurat_object, label = F, features  = "oligodendrocyte_precursor_cells_feature_score1", order = TRUE) + 
    ggtitle("oligodendrocyte precursors score")
  p9 = FeaturePlot(seurat_object, label = F, features  = "oligodendrocytes_feature_score1", order = TRUE) + 
    ggtitle("oligodendrocytes score") 
  p10 = FeaturePlot(seurat_object, label = F, features  = "endothelial_cells_feature_score1", order = TRUE) + 
    ggtitle("endothelial score")  
  p11 = FeaturePlot(seurat_object, label = F, features  = "smooth_muscle_cells_feature_score1", order = TRUE) + 
    ggtitle("smooth_muscle score") 

  p =  (p2 | p3) / (p4 | p5) / (p6 | p7) / (p8 | p9) / (p10 | p11)
  
  return(p)
}

p = UMAP_scores(human_seurat)

png( paste0("../inspection_30k_microglia_enriched/UMAP_30k_cells_noRegression_scores.png"), 
     width = 10, height = 18, units = "in", res = 400)
print(p)
dev.off()

p = FeaturePlot(human_seurat,features = unique(unlist(cell_type_list)), ncol = 3,order = T)

png( paste0("../inspection_30k_microglia_enriched/UMAP_30k_cells_noRegression_individual_markers.png"), 
     width = 15, height = 30, units = "in", res = 400)
print(p)
dev.off()

p = DoHeatmap(subset(human_seurat, downsample = 100),features =  unique(unlist(cell_type_list)),group.by = "seurat_clusters")

png( paste0("../inspection_30k_microglia_enriched/UMAP_30k_cells_noRegression_individual_markers_heatmap.png"), 
     width = 10, height = 18, units = "in", res = 400)
print(p)
dev.off()



human_seurat.markers <- FindAllMarkers(human_seurat, 
                                      only.pos = TRUE, 
                                      min.pct = 0.25, 
                                      logfc.threshold = 0.25, 
                                      test.use = "wilcox")


top5_markers <- human_seurat.markers %>% 
  group_by(cluster) %>% 
  top_n(n = 5, wt = avg_logFC)

png("../inspection_30k_microglia_enriched/UMAP_30k_cells_noRegressionheatmap_top_5_markers.png", 
    width = 10, height = 10, units = "in", res = 400)


DoHeatmap(subset(human_seurat, downsample = 100), features = top5_markers$gene, size = 4) + NoLegend()

dev.off()

## Annotating clusters
new.cluster.ids <- c("Neuron_glutamanergic_c0",
                     "Microglia_c1",
                     "Neuron_glutamanergic_c2",
                     "Neuron_glutamanergic_c3",
                     "Astrocytes",
                     "Neuron_gabaergic_c5",
                     "Oligodendrocytes_and_precursors",
                     "Neuron_gabaergic_SST",
                     "Neuron_unknown_c8",
                     "Endothelial",
                     "Smooth_muscle", 
                     "Blood",
                     "Microglia_c12",
                     "Microglia_c13")
names(new.cluster.ids) <- levels(human_seurat)
human_seurat <- RenameIdents(human_seurat, new.cluster.ids)
human_seurat$renamed_clusters = Idents(human_seurat)


png("../inspection_30k_microglia_enriched/UMAP_30k_cells_noRegression_renamedClusters.png", 
    width = 10, height = 10, units = "in", res = 400)


DimPlot(human_seurat, label = TRUE) + NoLegend() + ggtitle("Renamed clusters")

dev.off()

saveRDS(human_seurat,"../seurat_30K_microglia_enriched_filtered_noRegression_humanOrthologs.rds")
