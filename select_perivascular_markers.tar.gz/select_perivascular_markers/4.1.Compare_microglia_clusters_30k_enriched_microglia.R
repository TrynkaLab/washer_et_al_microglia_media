## Comparing microglia clusters
# Differential expression tables were used to build supplementary table 6
library(Seurat)
library(patchwork)
library(ggplot2)
library(future)
options(stringsAsFactors = FALSE)

options(future.globals.maxSize= 2097152000) # 2Gb for seurat
plan("multiprocess", workers = 18) # more workers
# check the current active plan
plan()

# Load data
brain10x=readRDS("../seurat_30K_microglia_enriched_filtered_CCycleMouseRegression_humanOrthologs.rds")
levels(Idents(brain10x))

# Plot expression of specific markers
cell_type_list = list(microglia=c("P2Y12","TREM2","ITGAM","HEXB",
                                  "SPI1"), # Pu.1
                      pvM=c("IGFR3","FCG3A", # CD16
                            "CD68", # classic macrophage marker
                            "MRC1", # CD206
                            "SIGLEC1", # CD169
                            "C15" # could be monocytes or macrophages
                      ),
                      monocyte=c("CD14")) # monocytes are high CD14 and low CD16

p = DoHeatmap(subset(brain10x, downsample = 100),features =  unique(unlist(cell_type_list)),group.by = "seurat_clusters")

png( paste0("../inspection_30k_microglia_enriched/UMAP_30k_cells_noRegression_microglia_pvM_monocyte_markers_heatmap.png"), 
     width = 10, height = 18, units = "in", res = 400)
print(p)
dev.off()






## Comparing microglia C14 to microglia c1
comparison =  FindMarkers(brain10x, ident.1 = "Microglia_c14", ident.2 = "Microglia_c1", 
                          min.pct = 0.25, test.use = "wilcox")
higher_in_c14 = comparison[comparison$avg_logFC>0 & comparison$p_val_adj<0.01,]
higher_in_c1 = comparison[comparison$avg_logFC<0 & comparison$p_val_adj<0.01,]


write.table(higher_in_c1,"../inspection_30k_microglia_enriched/compare_microglia/30k_cells_CCycleMouseRegression_diffExpr_C14vsC1_higherC1.txt")
write.table(higher_in_c14,"../inspection_30k_microglia_enriched/compare_microglia/30k_cells_CCycleMouseRegression_diffExpr_C14vsC1_higherC14.txt")

png("../inspection_30k_microglia_enriched/compare_microglia/UMAP_30k_cells_CCycleMouseRegression_microglia_diffExpr_C14vsC1_higherC1_UMAP.png", 
    width = 10, height = 10, units = "in", res = 400)

FeaturePlot(brain10x, 
            features = rownames(higher_in_c1[1:9,]),
            order = T,ncol = 3)

dev.off()
png("../inspection_30k_microglia_enriched/compare_microglia/UMAP_30k_cells_CCycleMouseRegression_microglia_diffExpr_C14vsC1_higherC14_UMAP.png", 
    width = 10, height = 10, units = "in", res = 400)

FeaturePlot(brain10x, 
            features = rownames(higher_in_c14[1:9,]),
            order = T,ncol = 3)

dev.off()

## check if there is an enrichment in particular microglia subtypes
subtypes = list()
subtypes[["HM"]] = readLines("for_preprocess_Mancuso_label_transfer_data/SalaFrigerio_HomeostaticMicroglia.txt")[-1]
subtypes[["ARM"]] = readLines("for_preprocess_Mancuso_label_transfer_data/SalaFrigerio_ActivatedResponseMicroglia.txt")[-1]
subtypes[["CRM"]] = readLines("for_preprocess_Mancuso_label_transfer_data/Cytokine_response_microglia.txt")[-1]
subtypes[["macrophages"]] = readLines("for_preprocess_Mancuso_label_transfer_data/Prinz_CNS_associated_macrophages.txt")[-1]



gene_enrichment = function(test_genes, universe, enrichment_group, permutations = 10000){
  
  #' Generic enrichment test (overlaps) for bulk RNA-seq differentially expressed genes.
  #'
  #' @param test_genes Test of gene ids.
  #' @param universe The background for the null distribution.
  #' @param enrichment_group The group into which the matched_list is is being tested for overrepresentation/enrichment.
  #' @param permutations The number of permutations used to generate the null distribution.
  #' @return Returns a permuted p-value for overrepresentation.
  #' 
  
  
  ## null distribution of overlaps
  null_overlap_vector=c()
  for(p in 1:permutations){
    
    null_vector = sample(universe,length(test_genes))
    overlap = sum(null_vector %in% enrichment_group)
    null_overlap_vector = append(null_overlap_vector,overlap)
  }
  
  ## test overlap
  test_overlap = sum(test_genes %in% enrichment_group)
  
  # pval = probability of obtaining test results at least as extreme as the results actually observed, 
  # assuming that the null hypothesis is correct
  ## how often is null > test?
  pval = sum(null_overlap_vector > test_overlap)/permutations
  message(paste0("Tested vector length: ", length(test_genes)))  
  message(paste0("Enrichment vector length: ", length(enrichment_group)))  
  
  message(paste0("Histogram of null overlaps. Line: overlaps of tested genes - ", 
                 test_overlap, " overlapping genes")) 
  hist(null_overlap_vector)
  abline(v=test_overlap,col="red")
  
  enrichment <- data.frame(
    tested_size = length(test_genes), 
    enrichment_size  = length(enrichment_group), 
    overlap  =  test_overlap,  
    p_value  = pval, 
    overlap_gene_ids = ifelse(identical( test_genes[test_genes %in% enrichment_group], character(0)),"NA", 
                              paste(test_genes[test_genes %in% enrichment_group],collapse=",")),
    stringsAsFactors = FALSE
  )
  return(enrichment)
}

enrichment_c14 = list()
for(subtype in c("HM","ARM","CRM","macrophages")){
enrichment_c14[[subtype]] = gene_enrichment(rownames(higher_in_c14),
                                    universe = rownames(brain10x@assays$RNA),
                                    enrichment_group = subtypes[[subtype]])
}

enrichment_c1 = list()
for(subtype in c("HM","ARM","CRM","macrophages")){
  enrichment_c1[[subtype]] = gene_enrichment(rownames(higher_in_c1),
                                              universe = rownames(brain10x@assays$RNA),
                                              enrichment_group = subtypes[[subtype]])
}

enrichment_c14 = do.call("rbind",enrichment_c14)
enrichment_c1 = do.call("rbind",enrichment_c1)

enrichment_c14
enrichment_c1

write.table(enrichment_c1,"../inspection_30k_microglia_enriched/compare_microglia/30k_cells_CCycleMouseRegression_diffExpr_C14vsC1_enrichmentC1_microglia_categories.txt")
write.table(enrichment_c14,"../inspection_30k_microglia_enriched/compare_microglia/30k_cells_CCycleMouseRegression_diffExpr_C14vsC1_enrichmentC14_microglia_categories.txt")


## Based on literature search, I think we can conclude that C1 are microglia and C14 are perivascular macrophages
## C14 has perivascular macrophage markers LYVE1, CD163 and F13A1

levels(brain10x@meta.data$renamed_clusters) <- c(levels(brain10x@meta.data$renamed_clusters),"Perivascular_macrophages")
brain10x@meta.data[brain10x@meta.data$renamed_clusters == "Microglia_c14","renamed_clusters"] = "Perivascular_macrophages"

################# Compare C1 vs C15   ######################
comparison =  FindMarkers(brain10x, ident.1 = "Microglia_c15", ident.2 = "Microglia_c1", 
                          min.pct = 0.25, test.use = "wilcox")
higher_in_c15= comparison[comparison$avg_logFC>0 & comparison$p_val_adj<0.01,]
higher_in_c1 = comparison[comparison$avg_logFC<0 & comparison$p_val_adj<0.01,]


write.table(higher_in_c1,"../inspection_30k_microglia_enriched/compare_microglia/30k_cells_CCycleMouseRegression_diffExpr_C15vsC1_higherC1.txt")
write.table(higher_in_c15,"../inspection_30k_microglia_enriched/compare_microglia/30k_cells_CCycleMouseRegression_diffExpr_C15vsC1_higherC15.txt")

png("../inspection_30k_microglia_enriched/compare_microglia/UMAP_30k_cells_CCycleMouseRegression_microglia_diffExpr_C15vsC1_higherC1_UMAP.png", 
    width = 10, height = 10, units = "in", res = 400)

FeaturePlot(brain10x, 
            features = rownames(higher_in_c1[1:9,]),
            order = T,ncol = 3)

dev.off()
png("../inspection_30k_microglia_enriched/compare_microglia/UMAP_30k_cells_CCycleMouseRegression_microglia_diffExpr_C15vsC1_higherC15_UMAP.png", 
    width = 10, height = 10, units = "in", res = 400)

FeaturePlot(brain10x, 
            features = rownames(higher_in_c15[1:9,]),
            order = T,ncol = 3)

dev.off()

## check if there is an enrichment in particular microglia subtypes
subtypes = list()
subtypes[["HM"]] = readLines("for_preprocess_Mancuso_label_transfer_data/SalaFrigerio_HomeostaticMicroglia.txt")[-1]
subtypes[["ARM"]] = readLines("for_preprocess_Mancuso_label_transfer_data/SalaFrigerio_ActivatedResponseMicroglia.txt")[-1]
subtypes[["CRM"]] = readLines("for_preprocess_Mancuso_label_transfer_data/Cytokine_response_microglia.txt")[-1]
subtypes[["macrophages"]] = readLines("for_preprocess_Mancuso_label_transfer_data/Prinz_CNS_associated_macrophages.txt")[-1]



enrichment_c15= list()
for(subtype in c("HM","ARM","CRM","macrophages")){
  enrichment_c15[[subtype]] = gene_enrichment(rownames(higher_in_c15),
                                              universe = rownames(brain10x@assays$RNA),
                                              enrichment_group = subtypes[[subtype]])
}

enrichment_c1 = list()
for(subtype in c("HM","ARM","CRM","macrophages")){
  enrichment_c1[[subtype]] = gene_enrichment(rownames(higher_in_c1),
                                             universe = rownames(brain10x@assays$RNA),
                                             enrichment_group = subtypes[[subtype]])
}

enrichment_c15= do.call("rbind",enrichment_c15)
enrichment_c1 = do.call("rbind",enrichment_c1)

enrichment_c15
enrichment_c1

write.table(enrichment_c1,"../inspection_30k_microglia_enriched/compare_microglia/30k_cells_CCycleMouseRegression_diffExpr_C15vsC1_enrichmentC1_microglia_categories.txt")
write.table(enrichment_c15,"../inspection_30k_microglia_enriched/compare_microglia/30k_cells_CCycleMouseRegression_diffExpr_C15vsC1_enrichmentC15_microglia_categories.txt")


levels(brain10x@meta.data$renamed_clusters) <- c(levels(brain10x@meta.data$renamed_clusters),"Perivascular_macrophages")
brain10x@meta.data[brain10x@meta.data$renamed_clusters == "Microglia_c14","renamed_clusters"] = "Perivascular_macrophages"

## Based on literature search,  C15 could be monocytes or macrophages 
## C15 has among top diff expr genes monocyte marker CCR2 and macrophage/monocyte associated genes SELL, HP, S100A6
# S100A6 and IFITM3 are upregulated in brain with AD and correlate with amyloid beta production, respectively



levels(brain10x@meta.data$renamed_clusters) <- c(levels(brain10x@meta.data$renamed_clusters),"macrophage/monocyte")
brain10x@meta.data[brain10x@meta.data$renamed_clusters == "Microglia_c15","renamed_clusters"] = "macrophage/monocyte"


## save renamed
saveRDS(brain10x,"../seurat_30K_microglia_enriched_filtered_CCycleMouseRegression_humanOrthologs.rds")

## save Dimplot renamed 
brain10X = readRDS("../seurat_30K_microglia_enriched_filtered_CCycleMouseRegression_humanOrthologs.rds")
png("../inspection_30k_microglia_enriched/UMAP_30k_cells_noRegression_renamedClusters.png", 
    width = 8, height = 7, units = "in", res = 400)


DimPlot(brain10X, label = TRUE,group.by = "renamed_clusters") + NoLegend() + ggtitle("Renamed clusters")

dev.off()

