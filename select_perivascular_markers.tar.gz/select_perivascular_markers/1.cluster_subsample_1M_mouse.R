#  1.3M mouse data
# No metadata - so cluster from 20k subsample and annotation myself to use as reference 
# Matching mouse genes to human 
# Downloading
library(Seurat)
library(SingleCellExperiment)
options(DelayedArray.block.size=2e9) # Give 2GB memory to single cell experiment
library(future)
library(glmGamPoi) # To speed up SCTransform
library(patchwork)
library(tidyverse)
library(biomaRt)
plan("multiprocess", workers = 12) # more workers
# check the current active plan
plan()

subsample20 = Read10X_h5("1M_neurons_neuron20k.h5")
str(subsample20)
subsample20 = CreateSeuratObject(subsample20)

################################################## load cell metadata and add to this object ###############
subsample20@assays$RNA[301:310, 1:30]
subsample20[["percent.mt"]] <- PercentageFeatureSet(subsample20, pattern = "^mt-")

FeatureScatter(subsample20, feature1 = "nCount_RNA", feature2 = "nFeature_RNA") + NoLegend() +
  ylab("Number of genes") +
  xlab("UMI counts") + 
  geom_hline(yintercept = 300) 

FeatureScatter(subsample20, feature1 = "nCount_RNA", feature2 = "percent.mt") + NoLegend() +
  ylab("Mit percent") +
  xlab("UMI counts") + 
  geom_hline(yintercept = 5) 
VlnPlot(subsample20, features = "percent.mt")  + 
  geom_hline(yintercept = 5) 

subsample20 = subset(subsample20, subset = nFeature_RNA > 300 & percent.mt < 10)
dim(subsample20)

subsample20 = SCTransform(subsample20, method = "glmGamPoi", verbose = TRUE)


calculate_PCA_UMAP_neighbors_clusters = function(seurat_object){
  seurat_object <- RunPCA(seurat_object, verbose = FALSE)
  
  seurat_object <- FindNeighbors(seurat_object, dims = 1:30, verbose = FALSE)
  seurat_object <- FindClusters(seurat_object,
                                verbose = FALSE)
  
  seurat_object <- RunUMAP(seurat_object, dims = 1:30, verbose = FALSE)
  
  
  
  return(seurat_object)
}

subsample20 = calculate_PCA_UMAP_neighbors_clusters(subsample20)

UMAPS_per_lib = function(seurat_object) {
  p1 = DimPlot(seurat_object, label = TRUE) + NoLegend() + ggtitle("Clusters")
  p2 =FeaturePlot(seurat_object, label = F, features  = "percent.mt", order = TRUE) + 
    ggtitle("Mit percent") 
  p3 = FeaturePlot(seurat_object, label = F, features  = "nFeature_RNA", order = TRUE) + 
    ggtitle("Number of genes")
  p4 = FeaturePlot(seurat_object, label = F, features  = "nCount_RNA", order = TRUE) + 
    ggtitle("UMI counts")

  p = (p1 | p2) / (p3 | p4)

  return(p)
}

p = UMAPS_per_lib(subsample20)

png( "inspection_20k/UMAP_20k.png", 
     width = 8, height = 10, units = "in", res = 400)
p
dev.off()

subsample20.markers <- FindAllMarkers(subsample20, 
                               only.pos = TRUE, 
                               min.pct = 0.25, 
                               logfc.threshold = 0.25, 
                               test.use = "wilcox")


top5_markers <- subsample20.markers %>% 
  group_by(cluster) %>% 
  top_n(n = 5, wt = avg_logFC)

png("inspection_20k/heatmap_top_5_markers.png", 
     width = 10, height = 10, units = "in", res = 400)


DoHeatmap(subset(subsample20, downsample = 100), features = top5_markers$gene, size = 4) + NoLegend()

dev.off()
# plot microglia markers in mouse
# Some from DePaula-Silva et al # https://jneuroinflammation.biomedcentral.com/articles/10.1186/s12974-019-1545-x/figures/5

microglia_markers = c("P2ry12",
                      "Tmem119",
                      "Sall1",
                      "Sdk1",
                      "Trem2") 
macrophage_markers = c("Ms4a8a",
                       "Sectm1a",
                       "Trem1",
                       "Ptprc", # CD45
                       "Cd44")
png("inspection_20k/microglia_markers_heatmap.png", 
    width = 10, height = 3, units = "in", res = 400)

DoHeatmap(subset(subsample20, downsample = 100), features = microglia_markers, size = 4) + NoLegend()
dev.off()

png("inspection_20k/microglia_markers_UMAP.png", 
    width = 6, height = 6, units = "in", res = 400)

FeaturePlot(subsample20,features = microglia_markers, order = T)
dev.off()
VlnPlot(subsample20, features = microglia_markers)

DoHeatmap(subset(subsample20, downsample = 100), features = macrophage_markers, size = 4) + NoLegend()
FeaturePlot(subsample20,features = macrophage_markers)
VlnPlot(subsample20, features = macrophage_markers)

##  Looks like cluster 20 is microglia
# Looking at some of the enriched markers for this cluster
top10_markers <- subsample20.markers %>% 
  group_by(cluster) %>% 
  top_n(n = 10, wt = avg_logFC)
microglia_enriched = top10_markers[which(top10_markers$cluster==20),"gene"]

png("inspection_20k/top_diffexpr_microglia_cluster_heatmap.png", 
    width = 10, height = 6, units = "in", res = 400)

DoHeatmap(subset(subsample20, downsample = 100), features = microglia_enriched$gene, size = 4) + NoLegend()
dev.off()
png("inspection_20k/top_diffexpr_microglia_cluster_UMAP.png", 
    width = 10, height = 8, units = "in", res = 400)

FeaturePlot(subsample20,features = microglia_enriched$gene, order = T)
dev.off()
VlnPlot(subsample20, features = microglia_enriched$gene)

## Scoring cells according to microglia markers found in cluster 20
subsample20 <- AddModuleScore(
  object = subsample20,
  features = list(microglia_enriched$gene),
  ctrl = 100,
  name = 'microglia_Features'
)
head(subsample20@meta.data)
# Scores over 1 select microglial cluster
# Save for future use to pull microglial cells
write.table(microglia_enriched,"genes_for_microglial_scoring.txt")

# get human gene names with biomart
mouse_to_human = function(x){
  
  human = useMart("ensembl", dataset = "hsapiens_gene_ensembl")
  mouse = useMart("ensembl", dataset = "mmusculus_gene_ensembl")
  
  genesV2 = getLDS(attributes = c("mgi_symbol"), filters = "mgi_symbol", 
                   values = x , mart = mouse, attributesL = c("hgnc_symbol","ensembl_gene_id"), martL = human, 
                   uniqueRows=T)
  message("There are ", anyDuplicated(genesV2[, 2]), " duplicated human gene names")
  message("There are ", anyDuplicated(genesV2[, 3]), " duplicated human gene ids")
  
  ## Removing mouse genes that are not found in human and duplicates
  humanx <- genesV2[genesV2$HGNC.symbol != "",] 
  humanx <- humanx[which(!duplicated(humanx$HGNC.symbol)),] 
  humanx <- humanx[which(!duplicated(humanx$MGI.symbol)),] 
  
  message("After removing duplicates, there are ", anyDuplicated(humanx[, 1]), " duplicated mouse gene names")
  message("After removing duplicates, there are ", anyDuplicated(humanx[, 2]), " duplicated human gene names")
  message("After removing duplicates, there are ", anyDuplicated(humanx[, 3]), " duplicated human gene ids")
  
  print(head(humanx))
  return(humanx)
}
assayobj = GetAssayData(object = subsample20,
                                 assay = "RNA", slot = "data")
mouse_genes = row.names(assayobj)
human_mouse_genes = mouse_to_human(mouse_genes)

## Removing some mouse genes that are not in the data: don't know how they got here
human_mouse_genes = human_mouse_genes[human_mouse_genes$MGI.symbol!="Frmpd2",]
## Subsetting to mouse genes that have human orthologues, rename genes to human orthologs,
# and pull old metadata
subset_by_common_genes_and_rename = function(seurat_object, common_genes) {
  subset.matrix = GetAssayData(object = seurat_object,
                               assay = "RNA", slot = "counts")
  subset.matrix = subset.matrix[common_genes$MGI.symbol,]
  rownames(subset.matrix) = common_genes[match(common_genes$MGI.symbol,
                                               rownames(subset.matrix)),"HGNC.symbol"]
  subset_seurat_object =  CreateSeuratObject(subset.matrix) # Create a new Seurat object with just the genes of interest
  subset_seurat_object = AddMetaData(object = subset_seurat_object, metadata = seurat_object@meta.data) # Add the idents to the meta.data slot
  Idents(subset_seurat_object) = seurat_object@meta.data$seurat_clusters # Assign identities for the new Seurat object
  return(subset_seurat_object)
}

human_subsample20 = subset_by_common_genes_and_rename(seurat_object=subsample20, common_genes = human_mouse_genes)
# Save mouse seurat object and another one with human orthologue genes
saveRDS(subsample20,"1M_neurons_neuron20k_seurat_filtered.rds")
saveRDS(human_subsample20,"1M_neurons_neuron20k_seurat_filtered_human_orthologs.rds")
