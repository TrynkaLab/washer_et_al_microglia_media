# Determine optimal clustering parameters for 30k microglia-enriched object

library(clustree)
library(Seurat)
library(biomaRt)

options(future.globals.maxSize= 2097152000) # 2Gb for seurat
plan("multiprocess", workers = 18) # more workers
# check the current active plan
plan()

# Load un-filtered data

seurat = readRDS("../seurat_30K_microglia_enriched_nofilters.rds")

# load list of genes to use as microglia classifier
microglia_enriched_genes = read.table("../genes_for_microglial_scoring.txt")
microglia_enriched_genes = microglia_enriched_genes$gene

# Manually adding metadata
seurat@meta.data$nFeature_RNA = colSums(seurat@assays$RNA@counts > 0) #number of genes: all genes that have expression over 0 count
seurat@meta.data$nCount_RNA = colSums(seurat@assays$RNA@counts)
seurat[["percent.mt"]] =  PercentageFeatureSet(seurat, pattern = "^mt-")


## Mouse genes to human orthologs
# get human gene names with biomart
mouse_to_human = function(x){
  
  human = useMart("ensembl", dataset = "hsapiens_gene_ensembl")
  mouse = useMart("ensembl", dataset = "mmusculus_gene_ensembl")
  
  genesV2 = getLDS(attributes = c("mgi_symbol"), filters = "mgi_symbol", 
                   values = x , mart = mouse, attributesL = c("hgnc_symbol","ensembl_gene_id"), martL = human, 
                   uniqueRows=T)
  message("There are ", anyDuplicated(genesV2[, 2]), " duplicated human gene names")
  message("There are ", anyDuplicated(genesV2[, 3]), " duplicated human gene ids")
  
  ## Removing mouse genes that are not found in human and duplicates
  humanx <- genesV2[genesV2$HGNC.symbol != "",] 
  humanx <- humanx[which(!duplicated(humanx$HGNC.symbol)),] 
  humanx <- humanx[which(!duplicated(humanx$MGI.symbol)),] 
  
  message("After removing duplicates, there are ", anyDuplicated(humanx[, 1]), " duplicated mouse gene names")
  message("After removing duplicates, there are ", anyDuplicated(humanx[, 2]), " duplicated human gene names")
  message("After removing duplicates, there are ", anyDuplicated(humanx[, 3]), " duplicated human gene ids")
  
  print(head(humanx))
  return(humanx)
}
assayobj = GetAssayData(object = seurat,
                        assay = "RNA", slot = "data")
mouse_genes = row.names(assayobj)
human_mouse_genes = mouse_to_human(mouse_genes)
microglia_enriched_genes_human = mouse_to_human(microglia_enriched_genes)$HGNC.symbol
## Removing some mouse genes that are not in the data: don't know how they got here
human_mouse_genes = human_mouse_genes[human_mouse_genes$MGI.symbol!="Frmpd2",]
## Subsetting to mouse genes that have human orthologues, rename genes to human orthologs,
# and pull old metadata
subset_by_common_genes_and_rename = function(seurat_object, common_genes) {
  subset.matrix = GetAssayData(object = seurat_object,
                               assay = "RNA", slot = "counts")
  subset.matrix = subset.matrix[common_genes$MGI.symbol,]
  rownames(subset.matrix) = common_genes[match(common_genes$MGI.symbol,
                                               rownames(subset.matrix)),"HGNC.symbol"]
  subset_seurat_object =  CreateSeuratObject(subset.matrix) # Create a new Seurat object with just the genes of interest
  subset_seurat_object = AddMetaData(object = subset_seurat_object, metadata = seurat_object@meta.data) # Add the idents to the meta.data slot
  return(subset_seurat_object)
}

human_seurat = subset_by_common_genes_and_rename(seurat_object=seurat, common_genes = human_mouse_genes)

#Filter
seurat = subset(human_seurat, subset = nFeature_RNA > 300 & percent.mt < 10)
message("There are  ", nrow(human_seurat@meta.data), " cells now")

# Normalise
human_seurat = SCTransform(human_seurat, method = "glmGamPoi", verbose = T)


calculate_PCA_UMAP_neighbors_clusters = function(seurat_object){
  
  seurat_object <- RunPCA(seurat_object, verbose = FALSE)
  
  seurat_object <- FindNeighbors(seurat_object, dims = 1:30, verbose = FALSE)
  seurat_object <- FindClusters(seurat_object,
                                verbose = FALSE)
  
  seurat_object <- RunUMAP(seurat_object, dims = 1:30, verbose = FALSE)
  
  return(seurat_object)
}

human_seurat = calculate_PCA_UMAP_neighbors_clusters(human_seurat)

## Clustree
seurat_clusters <- FindClusters(
  object = human_seurat,
  reduction.type = "pca",
  resolution = c(0.1, 0.2, 0.3, 0.4, 0.6,0.8),
  dims.use = 1:30,
  save.SNN = TRUE
)


# Build cluster trees
clustree(seurat_clusters, prefix = "integrated_snn_res.",assay = "SCT")

png("../inspection_30k_microglia_enriched/UMAP_30k_cells_noRegression_cluster_resolution_tree.png", 
    width = 6, height = 10, units = "in", res = 400)
clustree(seurat_clusters, prefix = "integrated_snn_res.",assay = "SCT")
dev.off()

png("../inspection_30k_microglia_enriched/UMAP_30k_cells_noRegression_cluster_resolution_overlay_pca.png", 
    width = 6, height = 4, units = "in", res = 400)
clustree_overlay(seurat_clusters, "pca1", "pca2", red_dim = "pca")

dev.off()

png("../inspection_30k_microglia_enriched/UMAP_30k_cells_noRegression_cluster_resolution_overlay_umap.png", 
    width = 6, height = 4, units = "in", res = 400)
clustree_overlay(seurat_clusters, "umap1", "umap2", red_dim = "umap")

dev.off()

